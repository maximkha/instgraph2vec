"""
instgraph2vec

An interface for graph2vec
"""

__version__ = "0.1.0"
__author__ = 'Maxim Khanov'

import instgraph2vec.Embed as Embed