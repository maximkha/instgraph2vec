"""
instgraph2vec

An interface for graph2vec
"""

__version__ = "0.1.0"
__author__ = 'Maxim Khanov'

from . import embed as embed
__all__ = ["embed"]